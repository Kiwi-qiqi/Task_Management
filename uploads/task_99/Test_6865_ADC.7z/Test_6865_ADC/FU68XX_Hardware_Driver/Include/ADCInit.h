/**
 * @file	 FU6866.h
 * @version	 V1.0.0
 * @author	 FortiorTech Hardware Team
 * @date	 2021-07-15	22:25:48
 * @brief	 This file contains	...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */

/**
 * @file     ADCInit.h
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2025-10-16
 * @brief	 该文件包含了...
 *
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */

#ifndef __ADCINIT_H__
#define __ADCINIT_H__

typedef struct
{
	uint16 adcVsp;
} adcSample;


extern adcSample xdata adcSampleValue;

extern void ADC_Init(void);

#endif