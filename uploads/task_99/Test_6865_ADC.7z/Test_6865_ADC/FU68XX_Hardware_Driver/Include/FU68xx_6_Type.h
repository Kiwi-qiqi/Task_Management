/**
 * @copyright (C) COPYRIGHT 2022 Fortiortech Shenzhen
 * @file      FU68xx_Type.h
 * @author    Bruce, R&D
 * @since     2021-11-24 00:00:00
 * @date      2022-09-20 14:23:42
 * @note      Last modify author is Any Lin, R&D
 * @brief
 */

#ifndef __FU68XX_6_TYPE_H__
#define __FU68XX_6_TYPE_H__

#include <ctype.h> 
#include <stdbool.h>

/*******************************************************************************///Define Macro
#define _I                              volatile const                          /**< Defines 'read only' permissions */
#define _O                              volatile                                /**< Defines 'write only' permissions */
#define _IO                             volatile                                /**< Defines 'read&write' permissions */
/******************************************************************************///Define Type
typedef unsigned char                   uint8;
typedef unsigned short                  uint16;
typedef unsigned long                   uint32;
typedef long                            int32;
typedef short                           int16;
typedef char                            int8;

typedef enum{DISABLE = 0, ENABLE}       ebool;
/*******************************************************************************///Function Subject
#define SetReg(reg, val1, val2)         ((reg) = (reg) & (~(val1)) | (val2))    /**< reg中先对val1对应位写0, 后val2对应位写1, 其结果写回reg */
#define SetBit(reg, val)                ((reg) |=  (val))                       /**< reg中val对应位写1 */
#define ClrBit(reg, val)                ((reg) &= ~(val))                       /**< reg中val对应位写0 */
#define XorBit(reg, val)                ((reg) ^=  (val))                       /**< reg中val对应位取反 */
#define ReadBit(reg, val)               (((reg) & (val)) != 0)                  /**< 判断reg中val对应位是否为1 */

#endif
