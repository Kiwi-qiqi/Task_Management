/**
 * @file     main.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2025-10-16	
 * @brief	 该文件包含了...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */


/**
 * Function name   : main.c
 * Description     : 主函数
 * Date            : 2025-10-16
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
#include "MyProject.h"

adcSample xdata adcSampleValue;


void main(void)
{
	adcSampleValue.adcVsp = 0;
	
	/*------ADC初始化------*/
	ADC_Init();
	
	while (1)
	{
		SetBit(P0_OE, P01);
		
		SetBit(P0_PU, P01);
		
		GP01 = 0;
		
		SetBit(ADC_CR, ADCBSY);      //启动ADC转换，转换成功后硬件清0
		
		if (ReadBit(ADC_CR, ADCIF))   //判断转换是否完成
		{
			
			adcSampleValue.adcVsp = (uint16)(ADC7_DR);
			
		}
			
			
	}
	
}
