/**
 * Function    : ADCInit.c
 * Description : ADC初始化
 * Date        : 2025-10-16
 * @brief	 该文件包含了...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 
#include "MyProject.h"

void ADC_Init(void)
{
	SetBit(P3_AN, P34);         //AD7对应端口设置为模拟功能
	SetBit(ADC_MASK, CH7EN);    //通道使能

	SetBit(ADC_CR, ADCALIGN);   //adc数据左次高对齐 0-->Disable 1-->Enable

	ClrBit(ADC_CR, ADCIE);      //禁止ADC中断

	ADC_SCYC = 0x07;           //ADC通道采样时钟周期设置

	SetBit(ADC_CR, ADCEN);     //adc使能

	/* -----VREF参考电压设置 ----- */
	//00-->4.5V 01-->VDD5  10-->3.0V  11-->4.0V
	ClrBit(VREF_VHALF_CR, VRVSEL1);
	SetBit(VREF_VHALF_CR, VRVSEL0);
	
	
	/* -----使能内部 VREF 参考 ----- */
	SetBit(VREF_VHALF_CR, VREFEN);
	

}
