/**
 * @file	 FU6866.h
 * @version	 V1.0.0
 * @author	 FortiorTech Hardware Team
 * @date	 2021-07-15	22:25:48
 * @brief	 This file contains	...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */

#ifndef __MYPROJECT_H__
#define __MYPROJECT_H__

#include "FU68xx_6.h"
#include "TIMER.h"
#include <FU68xx_6_MCU.h>

#endif