/**
 * @file	 TIMER.h
 * @version	 V1.0.0
 * @author	 FortiorTech Hardware Team
 * @date	 2021-07-15	22:25:48
 * @brief	 This file contains	...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */

#ifndef __TIMER_H__
#define __TIMER_H__

#define TIMER3_MODE      (MODE2)                  //模式选择
#define MODE0               0                     //1ms定时器
#define MODE1               1                     //高低电平输出
#define MODE2               2                     //PWM捕获

typedef struct
{
	uint16 pwmCompare;
	uint16 pwmArr;
} TimeCntl;

extern TimeCntl xdata TIMER;
extern void Timer3_PWMOut_Init(void);
extern void Timer3_HighOut_Init(void);
extern void Timer3_PWMCapture_Init(void);

#endif