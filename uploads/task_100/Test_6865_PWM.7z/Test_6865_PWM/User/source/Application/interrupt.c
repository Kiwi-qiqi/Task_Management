/**
 * @file	 interrupt.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2025-10-17	
 * @brief	 该文件包含了...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 



/**
 * Function     : TIM3_INT
 * Description  : 清除中断，计算周期时间和高电平时间
 * Date         : 2025-10-17
 * Parameter    : None
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
#include "MyProject.h"
#include "TIMER.h"

TimeCntl xdata TIMER;

void TIM3_ISR(void) interrupt 9
{
	if (ReadBit(TIM3_CR1, T3IF))        //基本定时器上溢出中断
	{
		ClrBit(TIM3_CR1, T3IF);        //清除上溢标志位
	}
	if (ReadBit(TIM3_CR1, T3IR))       //基本定时器上溢出中断
	{
		ClrBit(TIM3_CR1, T3IR);        //清除上溢标志位
	}

#if(TIMER3_MODE == MODE2)
    {
     if(ReadBit(TIM3_CR1, T3IP))        //周期中断
           {
           	TIMER.pwmCompare = TIM3__DR;        //高电平时间
           	TIMER.pwmArr = TIM3__ARR;            //周期时间
            ClrBit(TIM3_CR1, T3IP); 
           }
    }
#elif(TIMER3_MODE == MODE1)
    {
		ClrBit(TIM3_CR1, T3IP);            //清除周期中断标志位
    }
#else
	{
		ClrBit(TIM3_CR1, T3IP);            //清除周期中断标志位
	}

#endif
	
}
