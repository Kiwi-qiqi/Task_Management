/**
 * @file	 main.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2021-07-15	22:30:17
 * @brief	 该文件包含了...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 


/*
 * Function name   :  mian.c
 * Description     :  主函数
 * Date            : 2015-10-17
 * @brief 编写你的说明文字... 
 * @return 
 */

#include "MyProject.h"

void main(void)
{
#if (TIMER3_MODE == MODE0)  //定时
	{
		/*-----Timer3定时器初始化------*/
		Timer3_PWMOut_Init();	
	}
#elif(TIMER3_MODE == MODE1)  //输出
    {
        /*-----Timer3定时器初始化------*/
		Timer3_HighOut_Init();	
    }
#else                       //捕获
    {
        /*-----Timer3定时器初始化------*/
		Timer3_PWMCapture_Init();
    }

#endif

	EA = 1;                 //打开中断全局使能
	while (1);
	
	
}

