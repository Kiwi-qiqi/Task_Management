/**
 * @file	 TIMER.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2021-07-15	22:30:17
 * @brief	 该文件包含了...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 
/**
 * Function     : Timer3_PWMOut_Init
 * Description  : PWM输出模式TIM3初始化
 * Date         : 2025-10-17
 * Parameter    : None
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */

#include "MyProject.h"


void Timer3_PWMOut_Init(void)
{
	ClrBit(TIM3_CR1, T3EN);    //0-停止技术；1-开始计数
	SetBit(PH_SEL, T3SEL);     //1-连接到端口GP1
	
	
	SetReg(TIM3_CR0, T3PSC0 | T3PSC1 | T3PSC2, T3PSC1);  //时钟分频设置，00
	SetBit(TIM3_CR0, T3OCM);                             //输出比较器匹配模块
	SetBit(TIM3_CR0, T3MOD);                             //模式选择
	
	SetBit(TIM3_CR0, T3IRE);                             //比较匹配中断使能
	ClrBit(TIM3_CR0, T3OPM);                             //0，在发生更新事件
	ClrBit(TIM3_CR1, T3IR| T3IF| T3IP);                  //清除中断标志位
	SetBit(TIM3_CR1, T3IPE | T3IFE);                     //输入有效边沿变化
	
	
	
	ClrBit(IP2, PTIM31);
	SetBit(IP2, PTIM30);
	
    //PTIM31 = 0;
    //PTIM30 = 1;                                          //TIM3中断优先级
	EA = 1;
	TIM3__DR = 4000;                                    //输入模式，DR和ARR
	TIM3__ARR = 6000;
	TIM3__CNTR = 0;
	SetBit(TIM3_CR1, T3EN);                            //使能计数器，启动
	
}

/**
 * Function     : Timer3_PWMCapture_Init
 * Description  : PWM捕获模式TIM3初始化
 * Date         : 2025-10-17
 * Parameter    : None
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
void Timer3_PWMCapture_Init(void)
{
	ClrBit(TIM3_CR1, T3EN);            //0-停止技术；1-开始计数
	SetBit(PH_SEL, T3SEL);             //1-P1.1作为

	ClrBit(TIM3_CR0, T3PSC2);          //计数器时钟分频选择
	ClrBit(TIM3_CR0, T3PSC1);          //000-->24M     001-->12M
	SetBit(TIM3_CR0, T3PSC0);          //100-->1.5M    101-->750K


	ClrBit(TIM3_CR0, T3OCM);                             //输出比较器匹配模块，
	ClrBit(TIM3_CR0, T3MOD);                             //T3MOD = 0 输入Timer模式
	SetBit(TIM3_CR0, T3IRE);                             //比较匹配中断使能
	
	ClrBit(TIM3_CR1, T3NM1);                             //输入噪声脉宽选择
	ClrBit(TIM3_CR1, T3NM0);                             //00-->不滤波


	ClrBit(TIM3_CR1, T3IR | T3IF | T3IP);                //清楚中断标志位
	SetBit(TIM3_CR1, T3IPE | T3IFE);                     //输入有效边沿变化中断使能
	ClrBit(TIM3_CR0, T3OPM);                             //计数器不停止


	ClrBit(IP2, PTIM31);
	SetBit(IP2, PTIM30);
	//PTIM31 = 0;
	//PTIM30 = 1;                                         //TIM3中断优先级
	EA = 1;                                             //打开中断总开关

	TIM3__DR = 0;                                    //输入模式，DR和ARR的值由硬件写
	TIM3__ARR = 0;
	TIM3__CNTR = 0;
	SetBit(TIM3_CR1, T3EN);                            //使能计数器，启动

}
/**
 * Function     : Timer3_HighOut_Init
 * Description  : PWM输出高电平TIM3初始化
 * Date         : 2025-10-17
 * Parameter    : None
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
void Timer3_HighOut_Init(void)
{
	ClrBit(TIM3_CR1, T3EN);    //0-停止技术；1-开始计数
	SetBit(PH_SEL, T3SEL);     //1-P1.1作为
	
	ClrBit(TIM3_CR0, T3PSC2);   //计数器时钟分频选择
	ClrBit(TIM3_CR0, T3PSC1);   //000-->24M     001-->12M
	SetBit(TIM3_CR0, T3PSC0);   //100-->1.5M    101-->750K


	SetBit(TIM3_CR0, T3OCM);                             //输出比较器匹配模块，
	SetBit(TIM3_CR0, T3MOD);                             //T3MOD = 0 输入Timer模式
	ClrBit(TIM3_CR1, T3NM1);                             //输入噪声脉宽选择
	ClrBit(TIM3_CR1, T3NM0);                             //00-->不滤波

	
	ClrBit(TIM3_CR1, T3IR| T3IP| T3IF);                  //清楚中断标志位
	ClrBit(TIM3_CR1, T3IPE | T3IFE);                     //输入有效边沿变化中断使能
	ClrBit(TIM3_CR0, T3IRE);                             //输出模式，比较匹配中断使能
	ClrBit(TIM3_CR0, T3OPM);                              //计数器不停止
	

	ClrBit(IP2, PTIM31);
	SetBit(IP2, PTIM30);
	//PTIM31 = 0;
	//PTIM30 = 1;                                         //TIM3中断优先级
	EA = 1;                                             //打开中断总开关
	
	TIM3__DR = 24000;                                    //输入模式，DR和ARR的值由硬件写
	TIM3__ARR = 0;
	TIM3__CNTR = 0;
	SetBit(TIM3_CR1, T3EN);                            //使能计数器，启动

}