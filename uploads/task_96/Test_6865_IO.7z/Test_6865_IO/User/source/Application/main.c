/**
 * @file	 main.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2021-07-15	21:12:10
 * @brief	 该文件包含了main函数和中断初始化函数...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 
#include "FU68xx_5.h"


/**@brief 编写你的说明文字... 
 * @return None
 */
void main(void)
{

	
	while(1)
	{
		
		SetBit(P0_OE, P01);
		SetBit(P0_PU, P01);
		GP01 = 0;
	}
	
}





