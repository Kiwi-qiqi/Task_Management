/**
 * @file	 interrupt.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2021-07-15	21:12:10
 * @brief	 该文件包含了...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 
#include "MyProject.h"


/*
 * Function Name : INT1_INT
 * Description   : 外部中断0
 * Date          : 2025-10-15
 * Parameter     : None
 * *@brief 编写你的说明文字... 
 * @return None
 */
void INIT0(void) interrupt 1
{
	if (ReadBit(LVSR, EXT0CFG0) & ReadBit(LVSR, EXT0CFG1) & ReadBit(LVSR, EXT0CFG2))
	{
     
		//SetBit(P0_OE, P01);
	    //P0_OE = (1<<3);
	    //SetBit(P0_PU, P01);
		GP01 =~ GP01;
		SetBit(LVSR, EXT0CFG0);
		SetBit(LVSR, EXT0CFG1);
		SetBit(LVSR, EXT0CFG2);
	}
}
	
	