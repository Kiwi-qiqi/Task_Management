/**
 * @file	 FU68xx_5_MDU.h
 * @version	 V1.0.0
 * @author	 FortiorTech Hardware Team
 * @date	 2021-07-15	21:10:22
 * @brief	 This file contains	...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */

#ifndef	__FU68XX_5_MDU_H__
#define	__FU68XX_5_MDU_H__

// Include external	header file.
#include "FU68xx_5_MCU.h"

#ifdef __cplusplus
extern "C" {
#endif


#define	PI0				0
#define	PI1				1
#define	PI2				2
#define	PI3				3
#define	PI_(x)			PI##x
#define	PI_KP(x)		PI(x)##_KP
#define	PI_KI(x)		PI(x)##_KI
#define	PI_EK(x)		PI(x)##_EK
#define	PI_EK1(x)		PI(x)##_EK1
#define	PI_UKH(x)		PI(x)##_UKH
#define	PI_UKL(x)		PI(x)##_UKL
#define	PI_UKMAX(x)		PI(x)##_UKMAX
#define	PI_UKMIN(x)		PI(x)##_UKMIN


#define	PID2			2
#define	PID3			3
#define	PID(x)			PI##x
#define	PID_KP(x)		PID(x)##_KP
#define	PID_KI(x)		PID(x)##_KI
#define	PID_KD(x)		PID(x)##_KD
#define	PID_EK(x)		PID(x)##_EK
#define	PID_EK1(x)		PID(x)##_EK1
#define	PID_EK2(x)		PID(x)##_EK2
#define	PID_UKH(x)		PID(x)##_UKH
#define	PID_UKL(x)		PID(x)##_UKL
#define	PID_UKMAX(x)	PID(x)##_UKMAX
#define	PID_UKMIN(x)	PID(x)##_UKMIN

#define	LPF0			0
#define	LPF1			1
#define	LPF2			2
#define	LPF3			3
#define	LPF(x)			LPF##x
#define	LPF_K(x)		LPF(x)##_K
#define	LPF_X(x)		LPF(x)##_X
#define	LPF_YH(x)		LPF(x)##_YH
#define	LPF_YL(x)		LPF(x)##_YL

#define	MUL0			0
#define	MUL1			1
#define	MUL2			2
#define	MUL3			3
#define	MUL(x)			MUL##x
#define	MUL_MA(x)		MUL(x)_MA
#define	MUL_MB(x)		MUL(x)_MB
#define	MUL_MCH(x)		MUL(x)_MCH
#define	MUL_MCL(x)		MUL(x)_MCL


#define	DIV0			0
#define	DIV1			1
#define	DIV2			2
#define	DIV3			3
#define	DIV(x)			DIV##x
#define	DIV_DAH(x)		DIV(x)_DAH
#define	DIV_DAL(x)		DIV(x)_DAL
#define	DIV_DB(x)		DIV(x)_DB
#define	DIV_DQH(x)		DIV(x)_DQH
#define	DIV_DQL(x)		DIV(x)_DQL
#define	DIV_DR(x)		DIV(x)_DR

typedef	struct
{
	int16 ref;
	int16 kp;
	int16 ki;
	int16 ek;
	int16 ek1;
	int16 ukmax;
	int16 ukmin;
	int16 ukh;
	int16 ukl;
}pi_type;
typedef	struct
{
	int16 ref;
	int16 kp;
	int16 ki;
	int16 kd;
	int16 ek;
	int16 ek1;
	int16 ek2;
	int16 ukmax;
	int16 ukmin;
	int16 ukh;
	int16 ukl;
}pid_type;
typedef	struct
{
	int16 k;
	int16 x;
	int16 yh;
	int16 yl;
}lpf_type;

/**
 * @brief SMDU的模式类型
 *
 * @note 使用@ref SMDU_RunNoBlock时, 其中的mode参数可以直接使用本枚举的内容
 * @note 使用@ref SMDU_RunBlock时, 其中的mode参数可以直接使用本枚举的内容
 */
typedef	enum
{
	S1MUL	= 0, /**< 有符号乘法, 计算结果左移1位 */
	SMUL	= 1, /**< 有符号乘法 */
	UMUL	= 2, /**< 无符号乘法 */
	DIV		= 3, /**< 32/16无符号除法 */
	SIN_COS	= 4, /**< Sin/Cos */
	ATAN	= 5, /**< ATan */
	LPF		= 6, /**< 低通滤波 */
	P_I		= 7	 /**< PI */
} ETypeSMDUMode;


/**
 * @brief 运行SMDU且不等待运行结束
 *
 * @param  stan	(0-3) 要启动的计算单元编号
 * @param  mode	(0-7) 指定计算单元的模式, 可使用@ref ETypeSMDUMode 作为计算模式的设置\n
 * @ref	S1MUL	有符号乘法,	计算结果左移1位	\n
 * @ref	SMUL	有符号乘法 \n
 * @ref	UMUL	无符号乘法 \n
 * @ref	DIV		32/16无符号除法	\n
 * @ref	SIN_COS	Sin/Cos	\n
 * @ref	ATAN	ATan \n
 * @ref	LPF		低通滤波 \n
 * @ref	PI		PI \n
 */
#define	SMDU_RunNoBlock(stan, mode)	  do												  \
									  {													  \
										  MDU_CR = MDUSTA0 << stan | (unsigned char)mode; \
									  }	while (0)

/**
 * @brief 运行SMDU且等待运行结束
 *
 * @param  stan	(0-3) 要启动的计算单元编号
 * @param  mode	(0-7) 指定计算单元的模式, 可使用@ref ETypeSMDUMode 作为计算模式的设置\n
 * @ref	S1MUL	有符号乘法,	计算结果左移1位	\n
 * @ref	SMUL	有符号乘法 \n
 * @ref	UMUL	无符号乘法 \n
 * @ref	DIV		32/16无符号除法	\n
 * @ref	SIN_COS	Sin/Cos	\n
 * @ref	ATAN	ATan \n
 * @ref	LPF		低通滤波 \n
 * @ref	PI		PI \n
 */
#define	SMDU_RunBlock(stan,	mode)	do										 \
									{										 \
										SMDU_RunNoBlock(stan, mode);		 \
										while (MDU_CR &	MDUBSY);			 \
									} while	(0);

#if	0
#define	PI_Init(pi , x)				do\
									{\
										PI_KP(x) = pi.kp;\
										PI_KI(x) = pi.ki;\
										PI_EK(x) = pi.ek;\
										PI_EK1(x) =	pi.ek1;\
										PI_UKMAX(x)	= pi.ukmax;\
										PI_UKMIN(x)	= pi.ukmin;\
										PI_UKH(x) =	pi.ukh;\
										PI_UKL(x) =	pi.ukl;\
									}while(0)
#define	PI_Run(pi ,	x ,	INPUT)		do\
									{\
										PI_EK(x) = pi.ref -	INPUT;\
										SMDU_RunBlock(x	, PI);\
										pi.ukh = PI_UKH(x);\
										pi.ukl = PI_UKL(x);\
									}while(0)
#define	PID_Init(pid , x)			do\
									{\
										PID_KP(x) =	pid.kp;\
										PID_KI(x) =	pid.ki;\
										PID_KD(x) =	pid.kd;\
										PID_EK(x) =	pid.ek;\
										PID_EK1(x) = pid.ek1;\
										PID_EK2(x) = pid.ek2;\
										PID_UKMAX(x) = pid.ukmax;\
										PID_UKMIN(x) = pid.ukmin;\
										PID_UKH(x) = pid.ukh;\
										PID_UKL(x) = pid.ukl;\
									}while(0)

#define	PID_Run(pid	, x	, INPUT)	do\
									{\
										PID_EK(x) =	pid.ref	- INPUT;\
										SMDU_RunBlock(x	, PI);\
										pid.ukh	= PID_UKH(x);\
										pid.ukl	= PID_UKL(x);\
									}while(0)
#define	LPF_Init(lpf , ID)			do\
									{\
										LPF_K(ID) =	lpf.k;\
										LPF_X(ID) =	lpf.x;\
										LPF_YH(ID) = lpf.yh;\
										LPF_YL(ID) = lpf.yl;\
									}while(0)
#define	LPF_Run(lpf	, x	, INPUT)	do\
									{\
										LPF_X(x) =	INPUT;\
										SMDU_RunBlock(x	, LPF);\
										lpf.yh = LPF_YH(x);\
										lpf.yl = LPF_YL(x);\
									}while(0)
								
#define	SMUL_Run(smul_a,smul_b,smul_ch,smul_cl,x)	do\
													{\
														MUL_MA(x) =	smul_a;\
														MUL_MB(x) =	smul_b;\
														SMDU_RunBlock(x	, SMUL);\
														smul_ch	= MUL_MCH(x);\
														smul_cl	= MUL_MCL(x);\
													}while(0)
#define	UMUL_Run(umul_a,smul_b,umul_ch,umul_cl,x)	do\
													{\
														MUL_MA(x) =	umul_a;\
														MUL_MB(x) =	umul_b;\
														SMDU_RunBlock(x	, UMUL);\
														umul_ch	= MUL_MCH(x);\
														umul_cl	= MUL_MCL(x);\
													}while(0)
#define	S1MUL_Run(s1mul_a,s1mul_b,s1mul_ch,s1mul_cl,x)	do\
														{\
															MUL_MA(x) =	s1mul_a;\
															MUL_MB(x) =	s1mul_b;\
															SMDU_RunBlock(x	, S1MUL);\
															s1mul_ch = MUL_MCH(x);\
															s1mul_cl = MUL_MCL(x);\
														}while(0)
#define	DIV_Run(div_ah,div_al,div_b,div_qh,div_ql,div_r,x)		do\
																{\
																	DIV_DAH(x) = div_ah;\
																	DIV_DAL(x) = div_al;\
																	DIV_DB(x) =	div_b;\
																	SMDU_RunBlock(x	, DIV);\
																	div_qh = DIV_DQH(x);\
																	div_ql = DIV_DQL(x);\
																	div_r =	DIV_DR(x);\
																}while(0)																											

//External Function
extern void	MDU_Test(void);
extern void	PI_Test(void);
extern void	PID_Test(void);
extern void	LPF_Test(void);
extern void	sin_cos_Test(void);
extern void	atan_Test(void);
extern void	SMUL_Test(void);	
extern void	S1MUL_Test(void);
extern void	UMUL_Test(void);	
extern void	DIV_Test(void);														
extern void	PI0_Test(void);
extern void	PI1_Test(void);
extern void	PI2_Test(void);
extern void	PI3_Test(void);
extern void	PID2_Test(void);
extern void	PID3_Test(void);
extern void	LPF0_Test(void);
extern void	LPF1_Test(void);
extern void	LPF2_Test(void);
extern void	LPF3_Test(void);
extern void	SMDU_Test(void);
extern void	sin_cos_Test1(void);
#endif

#ifdef __cplusplus
}
#endif

#endif	//__FU68XX_5_MDU_H__


/*** (C) Copyright 2022	Fortior	Technology Co.,	Ltd. ***/
