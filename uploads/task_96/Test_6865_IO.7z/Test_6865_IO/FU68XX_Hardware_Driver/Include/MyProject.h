/********************************************************************************

 **** Copyright (C), 2020, Fortior Technology Co., Ltd.                      ****

 ********************************************************************************
 * File Name     : MyProject.h
 * Author        :
 * Date          : 2025-10-15
 * Description   : .C file function description
 * Version       : 1.0
 * Function List :
 * 

********************************************************************************/

#ifndef __MYPROJECT_H__
#define __MYPROJECT_H__

#include "FU68xx_5.h"

extern void Extil_Init(void);  //中断1初始化


#endif
