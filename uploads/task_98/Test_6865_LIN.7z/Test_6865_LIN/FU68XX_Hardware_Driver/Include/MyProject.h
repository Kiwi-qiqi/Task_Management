/**
 * @copyright (C) COPYRIGHT 2022 Fortiortech Shenzhen
 * @file      MyProject.h
 * @author    Fortiortech Appliction Team
 * @note      Last modify author is Kris.huang
 * @since     2017-12-27
 * @date      2022-07-14
 * @brief     This file contains all the common data types used for Motor Control.  
 *                      
 */


/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __MYPROJECT_H_
#define __MYPROJECT_H_

/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_6.h>


#include <DMA.h>
#include <Lin.h>



#endif