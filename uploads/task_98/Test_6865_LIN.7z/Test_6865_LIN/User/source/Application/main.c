/**
 * @file	 main.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2021-07-15	22:30:17
 * @brief	 该文件包含了...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 
#include "MyProject.h"


/**@brief 编写你的说明文字... 
 * @return 
 */
void main(void)
{
    EA = 1;	// 使能全局中断

	LIN_Init();
	
	while(1)
	{
		EOP_RXLIN(); // EOP,LIN接收数据，调速
        EOP_TXLIN(); // EOP,LIN反馈数据,10ms更新一次
	}
}




