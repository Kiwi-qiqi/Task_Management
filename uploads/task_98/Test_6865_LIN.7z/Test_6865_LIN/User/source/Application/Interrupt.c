/**
 * @copyright (C) COPYRIGHT 2022 Fortiortech Shenzhen
 * @file      Interrupt.c
 * @author    Fortiortech  Appliction Team
 * @date      2022-07-13
 * @brief     This file contains interrupt function used for Motor Control.
 */



#include "MyProject.h"

extern uint8 data g_1mTick;                   ///< 1ms滴答信号，每隔1ms在SYSTICK定时器被置1，需在大循环使用处清零
extern void HardwareInit(void);
extern void SoftwareInit(void);
uint16 xdata spidebug[4] = { 0 };             ///< SPI debug 输出通道缓存，SPI调试器会将该变量值进行输出



/** 
 * @brief        LIN中断函数
 * @note         用于收发LIN信号，处理LIN信号收发中断
 * @date         2022-07-14
 */


void int14(void) interrupt 14
{
	if (ReadBit(LIN_CR, LINIE))
	{
        if (ReadBit(LIN_CSR, CLRERR)) // 错误中断
        {
            /*----- 获取错误源 -----*/
            LIN_Error_Handing();
            ClrBit(LIN_CSR, CLRERR);
            ClrBit(LIN_CR, LINRW);
        }

        else if (ReadBit(LIN_SR, LINREQ)) /* 没有错误才能处理数据 */
        {
            loc_linBusTimeoutCnt = 0;  /* 有LIN信号清零休眠计数 */
            LIN_list();                /* 读取ID号并处理信号 */
            LIN_SR = (uint8)(~LINREQ); /* 清除中断 */
        }

        if (ReadBit(LIN_SR, LINDONE)) // 数据收发完成
        {
            ReceiveSYS(LIN_ID);         /* 处理接收完成的数据 */
            LIN_SR = (uint8)(~LINDONE); /* 清除中断 */
        }

        if (ReadBit(LIN_CSR, LINWAKEUP)) // 唤醒信号
        {
            SetReg(LIN_CSR, LINWAKEUP | CLRERR, CLRERR);
        }

        if (ReadBit(LIN_SR, LINIDLE)) // 总线空闲
        {
            SetReg(LIN_SR, LINDONE | LINIDLE | LINREQ, LINDONE | LINREQ);
        }
    }
}