/**
 * @file	 FU6866_MDU.h
 * @version	 V1.0.0
 * @author	 FortiorTech Hardware Team
 * @date	 2021-07-15	22:27:58
 * @brief	 This file contains	...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */

#ifndef	__FU68xx_6_MDU_H__
#define	__FU68xx_6_MDU_H__

// Include external	header file.
#include "FU68xx_6_MCU.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @addtogroup FU68xx_6_StdPeriphDriver_C51
 * @{
 * @defgroup MDU
 * @{
 * @defgroup MDU_TypeDefine
 * @{
 */

/**
 * @brief MDU的模式类型
 *
 * @note 使用@ref MDU_RunNoBlock 时, 其中的mode参数可以直接使用本枚举的内容
 * @note 使用@ref MDU_RunBlock 时, 其中的mode参数可以直接使用本枚举的内容
 */
typedef enum
{
    S1MUL   = 0,  /**< 有符号乘法16x16, 计算结果左移1位, 最小计算周期: 11 */
    SMUL    = 1,  /**< 有符号乘法16x16, 最小计算周期: 11 */
    UMUL    = 2,  /**< 无符号乘法16x16, 最小计算周期: 11 */
    DIV     = 3,  /**< 无符号除法32/16, 最小计算周期: 33 */
    SIN_COS = 4,  /**< Sin/Cos, 最小计算周期: 32 */
    ATAN    = 5,  /**< ATan, 最小计算周期: 30 */
    LPF     = 6,  /**< 低通滤波, 最小计算周期: 17 */
    PI      = 7,  /**< PI/PID, 最小计算周期: 30 */
} ETypeMDUMode;

/**
 * @}
 */
/******************************************************************************///External Symbols
/******************************************************************************///External Function
/**
 * @addtogroup FU68xx_6_StdPeriphDriver_C51
 * @{
 * @defgroup MDU
 * @{
 * @defgroup MDU_Function
 * @{
 */

/**
 * @brief 直接运行MDU
 *
 * @param  stan 要启动的计算单元编号[0~3]
 * @param  mode 指定计算单元的模式, 可直接使用@ref ETypeMDUMode 的值
 */
#define MDU_RunNoBlock(stan, mode) do                                                           \
                                   {                                                            \
                                       MDU_CR = MDUBSY | 1 << (stan + 3) | (unsigned char)mode; \
                                   } while (0)

/**
 * @brief 观前顾后的运行MDU
 *
 * @param  stan 要启动的计算单元编号[0~3]
 * @param  mode 指定计算单元的模式, 可直接使用@ref ETypeMDUMode 的值
 */
#define MDU_RunBlock(stan, mode) do                              \
                                 {                               \
                                     while (MDU_CR & MDUBSY);    \
                                     MDU_RunNoBlock(stan, mode); \
                                     while (MDU_CR & MDUBSY);    \
                                 } while (0)

/**
 * @}
 * @}
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif	//__FU68xx_6_MDU_H__

/*** (C) Copyright 2022	Fortior	Technology Co.,	Ltd. ***/
