/**
 * @file	 main.c
 * @version	 V1.0.0
 * @author	 FortiorTech Appliction	Team
 * @date	 2021-07-15	21:12:10
 * @brief	 该文件包含了main函数和中断初始化函数...
 * 
 * @copyright Copyright(C) 2022, Fortior Technology	Co., Ltd. All rights reserved.
 */
 
#include "MyProject.h"


/**@brief 编写你的说明文字... 
 * @return None
 */
void main(void)
{
	EA = 1;

	
	/*---中断1初始化----*/
	//SetBit(P0_OE, P03);
	//SetBit(P0_PU, P03);
	//GP03 = 1;

	
	Extil_Init();
	
	while(1)
	{
		
	}
	
}

/*
 * Function Name : Extil_Init
 * Description   : 中断0初始化
 * Date          : 2025-10-15
 * Parameter     : None
 */
void Extil_Init(void)
{
    //中断0使能
	EX0 = 1;

	//P03为外部中断P0.3接口
	SetBit(LVSR, EXT0CFG0);
	SetBit(LVSR, EXT0CFG1);
	ClrBit(LVSR, EXT0CFG2);
	
	
	
	//电平改变（上升或下降）触发中断
	IT01 = 1;
	IT00 = 1;
	
	// 测试用，验证进入中断

	SetBit(P0_OE, P01);
	//P0_OE = (1<<3);
	SetBit(P0_PU, P01);
	GP01 = 0;
	
	
}


